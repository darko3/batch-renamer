# A simple color module I wrote for my projects
# Feel free to copy this script and use it for your own projects!

class Color:
	purple = '\033[95m'
	blue = '\033[94m'
	green = '\033[92m'
	yellow = '\033[93m'
	red = '\033[91m'
	white = '\033[0m'

class textType:
	bold = '\033[1m'
	underline = '\033[4m'
    